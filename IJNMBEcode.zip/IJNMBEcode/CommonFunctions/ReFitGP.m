function gp_regr = ReFitGP(x_regr, y_regr)
% Fits and return GP regression  model to x and y

%% GP regression

% Hyperpriors
plg = prior_unif(); % prior for lengthscale
pms = prior_sqrtunif();
ps = prior_logunif(); % prior for sigma2 in the likelihood

% We allow for different lengthscale in every dimension (ARD)
% One magnitude as it is a 1 single output (rss 1x1)
lik = lik_gaussian('sigma2', exp(-9.950929526405522), 'sigma2_prior', ps);

gpcf = gpcf_sexp('lengthScale', 0.01*ones(1,size(x_regr,2)),...,
    'magnSigma2', 1,...
    'lengthScale_prior', plg, 'magnSigma2_prior', pms);

% Set a small amount of jitter to be added to the diagonal elements of the
% covariance matrix K to avoid singularities when this is inverted
jitter=1e-9;

% Create the GP structure
gp_regr = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);

% Set the options for the optimization
opt=optimset('TolFun',1e-3,'TolX',1e-3);

% Optimize with the scaled conjugate gradient method
gp_regr = gp_optim(gp_regr,x_regr,y_regr,'opt',opt);

end

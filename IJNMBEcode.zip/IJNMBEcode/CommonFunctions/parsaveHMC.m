function parsaveHMC(fname, p_sample, s2_sample, ss_sample, initime, fintime, acc)
save(fname, 'p_sample', 's2_sample', 'ss_sample', 'initime', 'fintime', 'acc')
end
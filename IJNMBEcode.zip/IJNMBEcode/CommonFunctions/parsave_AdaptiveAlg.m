function parsave_AdaptiveAlg(fname, p_sample, ss_sample, s2_sample)
save(fname, 'p_sample', 'ss_sample', 's2_sample')
end
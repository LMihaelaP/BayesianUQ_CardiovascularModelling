function FirstDeriv = BlackBoxFirstDeriv_phi(pressure, param_sc, extra_p, l, u)

% Calculates the derivative of the black-box sor06 w.r.t. every parameter 

% input: pressure, param, extra parameters

% output: the first derivative for every parameter

sor0 = pressure;

id = extra_p(1); nd = extra_p(2);

FirstDeriv = NaN(nd, numel(sor0)); % chosen first deriv for every parameter

%delete(gcp('nocreate'))
%parpool('local', nd)

parfor i = 1:nd
    
    if i == 1 %f3
        %h = 0.0001;
        h = 1e-6;
        param_sc_hplus = [param_sc(1)+h, param_sc(2), param_sc(3), ...
            param_sc(4)];

    elseif i == 2 % rr1
        %h = 0.0001;
        h = 1e-7;
        param_sc_hplus = [param_sc(1), param_sc(2)+h, param_sc(3), ...
            param_sc(4)];
        
    elseif i == 3 % rr2
        %h = 0.0001;
        h = 1e-6;
        param_sc_hplus = [param_sc(1), param_sc(2), param_sc(3)+h, ...
            param_sc(4)];
        
    else % cc1
        %h = 0.0001;
        h = 1e-7;
        param_sc_hplus = [param_sc(1), param_sc(2), param_sc(3), ...
            param_sc(4)+h];
        
    end
    
    param_hplus = (u.*exp(param_sc_hplus(1:4))+l)./(1+exp(param_sc_hplus(1:4)));
    
    cx = unix(sprintf('./sor06 %f %f %f %f %d', ...
        param_hplus(1), param_hplus(2), param_hplus(3), param_hplus(4), i+9));
    
    if cx == 0
        state = CreateData_Optim(i+9);
        sorh_plus = state(end/2+1:end);
    else
        sorh_plus = repmat(10^10, numel(sor0), 1);
    end
    
    FirstDeriv(i,:) = (sorh_plus - sor0)./h;
    
end


end

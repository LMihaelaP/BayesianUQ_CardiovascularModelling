/* The sor06.C main program */

// $Id: sor06.C,v 1.10 2005/10/14 18:05:59 heine Exp $

#include "sor06.h"
#include "tools.h"
#include "arteries.h"

extern "C"  void impedance_init_driver_(int *tmstps);

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>

using namespace std;

// The vessel-network is specified and initialized, and the flow and
// pressures are to be determed. All global constants must be defined
// in the header file. That is the number of dots per cm, and the number
// of vessels.
int main(int argc, char *argv[])
{
  double tstart, tend, finaltime;

  double rm  = 0.04;
    
    double f1   = 0;//1.99925e07;// 8.99925e07;
    double f2   = 1;//-25.5267;
//    double f3   = 0.1*8.7401569e05;// 1.95*8.65e05;
//
    //==========adjustment in resistances (WK parameters) for the control========
    
    double R41, R61, R81, R101, R111, R121, R141, R161, R181, R191, R201;
    double R42, R62, R82, R102, R112, R122, R142, R162, R182, R192, R202;
    double C4, C6, C8, C10, C11, C12, C14, C16, C18, C19, C20;
    
    R41 = 510.4072231; R61 = 388.0002164; R81 = 538.8259481; R101 = 466.9618518; R111= 1807.757766; R121 = 1173.676967;
    R141 = 201.7568994; R161 = 1083.333887; R181 = 111.4435425; R191 = 121.7038967; R201 = 86.80429871;
    
    R42 = 2041.628892; R62 = 1552.000866; R82 = 2155.303792; R102 = 1867.847407; R112 = 7231.031065; R122 = 4694.70787;
    R142 = 807.0275975;R162= 4333.335547; R182 = 445.7741702; R192 = 486.8155867; R202 = 347.2171949;
    
    C4 = 0.00526672; C6 = 0.006928275; C8 = 0.004988943; C10 = 0.005756727; C11 = 0.00148702; C12 = 0.002290385;
    C14 = 0.013323817; C16 = 0.002481388; C18 = 0.02412138; C19 = 0.022087806; C20 = 0.03096819;
    
    double a = 0.5, b = 0.5, d = 0.5;  //
    
    double f3, rr1, rr2, cc1;
    int id;

//    double f3 = 2.5e05;
//    double rr1 = 0.5;
//    double rr2 = 0.1;
//    double cc1 = 0.0;
//    double tap = 0.0;
    
    if (argc != 6) //argv[0] is the name of the program, here sor06
    {
        printf("Not enough input arguments, noargc %d and they are %s\n", argc, argv[0]);
        return 1;
    }
    
    f3 = atof(argv[1]);
    rr1 = atof(argv[2]);
    rr2 = atof(argv[3]);
    cc1 = atof(argv[4]);
    id = atof(argv[5]);
    
//    double rr1  = 0.2; // should be between -1/a and 1/a
//    double rr2  = -0.6;//   should be between -1/b and 1/b
//    double cc1 = 0;//    should be between -1/d and 1/d
    //    double rr2  = 4*rr1;   // Used when R1/RT is kept fixed at 0.2
    
    char namepu1 [20];
    
    sprintf(namepu1, "pu1_C_%d.2d", id);
    
    FILE *fpu1 = fopen (namepu1, "w");

/*char namepu2 [20];
    
    sprintf(namepu2, "pu2_C_%d.2d", id);
    
    FILE *fpu2 = fopen (namepu2, "w");
	
	char namepu3 [20];
    
    sprintf(namepu3, "pu3_C_%d.2d", id);
    
    FILE *fpu3 = fopen (namepu3, "w");
	
	char namepu4 [20];
    
    sprintf(namepu4, "pu4_C_%d.2d", id);
    
    FILE *fpu4 = fopen (namepu4, "w");
	
	char namepu5 [20];
    
    sprintf(namepu5, "pu5_C_%d.2d", id);
    
    FILE *fpu5 = fopen (namepu5, "w");
	
	char namepu6 [20];
    
    sprintf(namepu6, "pu6_C_%d.2d", id);
    
    FILE *fpu6 = fopen (namepu6, "w");
	
	char namepu7 [20];
    
    sprintf(namepu7, "pu7_C_%d.2d", id);
    
    FILE *fpu7 = fopen (namepu7, "w");
	
	char namepu8 [20];
    
    sprintf(namepu8, "pu8_C_%d.2d", id);
    
    FILE *fpu8 = fopen (namepu8, "w");
	
	char namepu9 [20];
    
    sprintf(namepu9, "pu9_C_%d.2d", id);
    
    FILE *fpu9 = fopen (namepu9, "w");
	
	char namepu10 [20];
    
    sprintf(namepu10, "pu10_C_%d.2d", id);
    
    FILE *fpu10 = fopen (namepu10, "w");
	
	char namepu11 [20];
    
    sprintf(namepu11, "pu11_C_%d.2d", id);
    
    FILE *fpu11 = fopen (namepu11, "w");
	
	char namepu12 [20];
    
    sprintf(namepu12, "pu12_C_%d.2d", id);
    
    FILE *fpu12 = fopen (namepu12, "w");
	
	char namepu13 [20];
    
    sprintf(namepu13, "pu13_C_%d.2d", id);
    
    FILE *fpu13 = fopen (namepu13, "w");
	
	char namepu14 [20];
    
    sprintf(namepu14, "pu14_C_%d.2d", id);
    
    FILE *fpu14 = fopen (namepu14, "w");
	
	char namepu15 [20];
    
    sprintf(namepu15, "pu15_C_%d.2d", id);
    
    FILE *fpu15 = fopen (namepu15, "w");
	
	char namepu16 [20];
    
    sprintf(namepu16, "pu16_C_%d.2d", id);
    
    FILE *fpu16 = fopen (namepu16, "w");
	
	char namepu17 [20];
    
    sprintf(namepu17, "pu17_C_%d.2d", id);
    
    FILE *fpu17 = fopen (namepu17, "w");
	
	char namepu18 [20];
    
    sprintf(namepu18, "pu18_C_%d.2d", id);
    
    FILE *fpu18 = fopen (namepu18, "w");
	
	char namepu19 [20];
    
    sprintf(namepu19, "pu19_C_%d.2d", id);
    
    FILE *fpu19 = fopen (namepu19, "w");
	
		char namepu20 [20];
    
    sprintf(namepu20, "pu20_C_%d.2d", id);
    
    FILE *fpu20 = fopen (namepu20, "w");
	
	char namepu21 [20];
    
    sprintf(namepu21, "pu21_C_%d.2d", id);
    
    FILE *fpu21 = fopen (namepu21, "w");
*/	
    
//    const char *namepu1  = "pu1.2d"; // "pu1_H1.2d";
//    const char *namepu2  = "pu2_C.2d"; // "pu1_H2.2d";
//    const char *namepu3  = "pu3_C.2d"; // "pu1_H3.2d";
    
//    fprintf(stdout, "Opening Files:\n");
    
//    FILE *fpu1 = fopen (namepu1, "w");
//    if (fpu1) fprintf(stdout, "1pu OK, "); else error ("main.C","File 1pu NOT OK");
//    FILE *fpu2 = fopen (namepu2, "w");
////    if (fpu2) fprintf(stdout, "2pu OK, "); else error ("main.C","File 2pu NOT OK");
//    FILE *fpu3 = fopen (namepu3, "w");
//    if (fpu3) fprintf(stdout, "3pu OK, "); else error ("main.C","File 3pu NOT OK");
//    fprintf(stdout, "\n");
    
  // Workspace used by bound_right

  // Workspace used by bound_bif
  for(int i=0; i<18; i++) fjac[i] = new double[18];

  //clock_t c1 = clock();        // Only used when timing the program.
  nbrves    = 21;             // The number of vessels in the network.
  tstart    = 0.0;            // Starting time.
  finaltime = 6*Period;       // Final end-time during a simulation.
  tend      = 5*Period;       // Timestep before the first plot-point
                              // is reached.

  // The number of vessels in the network is given when the governing array of
  // vessels is declared.

  impedance_init_driver_(&tmstps);

  Tube   *Arteries[nbrves];                    // Array of blood vessels.
    
    
    // Initialization of the Arteries.

   
    // Definition of Class Tube: (Length, topradius, botradius, *LeftDaughter, *RightDaughter, rmin, points, init, K, f1, f2, f3, R1, R2,  CT, LT);

    
    // =========================NETWORK MITCHELS CONSENSUS=================================================================================
    
    Arteries[20] = new Tube( 0.055, 0.018, 0.018, 0, 0, rm,40,0,0,f1,f2,f3, R201-a*rr1*R201, R202-b*rr2*R202, C20-d*cc1*C20, 0);
    Arteries[19] = new Tube( 0.178, 0.022, 0.022, 0, 0, rm,40,0,0,f1,f2,f3, R191-a*rr1*R191, R192-b*rr2*R192, C19-d*cc1*C19, 0);
    Arteries[18] = new Tube( 0.177, 0.015, 0.015, 0, 0, rm,40,0,0,f1,f2,f3, R181-a*rr1*R181, R182-b*rr2*R182, C18-d*cc1*C18, 0);
    
    Arteries[17] = new Tube( 0.469, 0.024, 0.024*(1-0.018), Arteries[ 19], Arteries[ 20], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[16] = new Tube( 0.302, 0.015, 0.015, 0, 0, rm,40,0,0,f1,f2,f3, R161-a*rr1*R161, R162-b*rr2*R162, C16-d*cc1*C16, 0);
    
    Arteries[15] = new Tube( 0.083, 0.025, 0.025*(1-0.018), Arteries[ 17], Arteries[ 18], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[14] = new Tube( 0.184, 0.019, 0.019, 0, 0, rm,40,0,0,f1,f2,f3, R141-a*rr1*R141, R142-b*rr2*R142, C14-d*cc1*C14, 0);
    
    Arteries[13] = new Tube( 0.081, 0.024, 0.024*(1-0.018), Arteries[ 15], Arteries[ 16], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[12] = new Tube( 0.062, 0.014, 0.014, 0, 0, rm,40,0,0,f1,f2,f3, R121-a*rr1*R121, R122-b*rr2*R122, C12-d*cc1*C12, 0);
    
    Arteries[11] = new Tube( 0.140, 0.015, 0.015, 0, 0, rm,40,0,0,f1,f2,f3, R111-a*rr1*R111, R112-b*rr2*R112, C11-d*cc1*C11, 0);
    
    Arteries[10] = new Tube( 0.069, 0.016, 0.016, 0, 0, rm,40,0,0,f1,f2,f3, R101-a*rr1*R101, R102-b*rr2*R102, C10-d*cc1*C10, 0);
    
    Arteries[9] = new Tube( 0.262, 0.020, 0.020*(1-0.018), Arteries[ 11], Arteries[ 12], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[8] = new Tube( 0.177, 0.017, 0.017, 0, 0, rm,40,0,0,f1,f2,f3, R81-a*rr1*R81, R82-b*rr2*R82, C8-d*cc1*C8, 0);
    
    Arteries[7] = new Tube( 0.311, 0.023, 0.023*(1-0.018), Arteries[ 9], Arteries[ 10], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[6] = new Tube( 0.212, 0.017, 0.017, 0, 0, rm,40,0,0,f1,f2,f3, R61-a*rr1*R61, R62-b*rr2*R62,C6-d*cc1*C6, 0);
    
    Arteries[5] = new Tube( 0.202, 0.032, 0.032*(1-0.018), Arteries[ 13], Arteries[ 14], rm,40,0,0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[4] = new Tube( 0.052, 0.013, 0.013, 0, 0, rm,40,0,0,f1,f2,f3, R41-a*rr1*R41, R42-b*rr2*R42, C4-d*cc1*C4, 0);
    
    Arteries[3] = new Tube( 0.241, 0.024, 0.024*(1-0.018), Arteries[ 7], Arteries[ 8], rm,40, 0, 0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[2] = new Tube( 0.372, 0.037, 0.037*(1-0.018), Arteries[ 5], Arteries[ 6], rm,40, 0, 0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[1] = new Tube( 0.445, 0.026, 0.026*(1-0.018), Arteries[ 3], Arteries[ 4], rm,40, 0, 0,f1,f2,f3, 0, 0, 0, 0);
    
    Arteries[0] = new Tube( 0.410, 0.047, 0.047*(1-0.018), Arteries[ 1], Arteries[ 2], rm,40, 1, 0,f1,f2,f3, 0, 0, 0, 0);
    

      // In the next three statements the simulations are performed until
  // tstart = tend. That is this is without making any output during this
  // first period of time. If one needs output during this period, these three
  // lines should be commented out, and the entire simulation done within the
  // forthcomming while-loop.

  // Solves the equations until time equals tend.
  solver (Arteries, tstart, tend, k);
  tstart = tend;
  tend = tend + Deltat;

  // fprintf (stdout,"saves Q0\n");
  // Arteries[ 0] -> printQ0(fq0);

//  fprintf (stdout,"plots start\n");

  // The loop is continued until the final time
  // is reached. If one wants to make a plot of
  // the solution versus x, tend is set to final-
  // time in the above declaration.
  while (tend <= finaltime)
  {
    for (int j=0; j<nbrves; j++)
    {
      int ArtjN = Arteries[j]->N;
      for (int i=0; i<ArtjN; i++)
      {
        Arteries[j]->Qprv[i+1] = Arteries[j]->Qnew[i+1];
        Arteries[j]->Aprv[i+1] = Arteries[j]->Anew[i+1];
      }
    }

    // Solves the equations until time equals tend.
    solver (Arteries, tstart, tend, k);
//    fprintf (stdout,".");

    // A 2D plot of P(x_fixed,t) is made. The resulting 2D graph is due to
    // the while loop, since for each call of printPt only one point is set.
      Arteries[ 0] -> printPxt (fpu1, tend, 0);
/*      Arteries[ 1] -> printPxt (fpu2, tend, 0);
      Arteries[ 2] -> printPxt (fpu3, tend, 0);
      Arteries[ 3] -> printPxt (fpu4, tend, 0);
      Arteries[ 4] -> printPxt (fpu5, tend, 0);
      Arteries[ 5] -> printPxt (fpu6, tend, 0);
      Arteries[ 6] -> printPxt (fpu7, tend, 0);
      Arteries[ 7] -> printPxt (fpu8, tend, 0);
      Arteries[ 8] -> printPxt (fpu9, tend, 0);
      Arteries[ 9] -> printPxt (fpu10, tend, 0);
      Arteries[ 10] -> printPxt (fpu11, tend, 0);
      Arteries[ 11] -> printPxt (fpu12, tend, 0);
      Arteries[ 12] -> printPxt (fpu13, tend, 0);
      Arteries[ 13] -> printPxt (fpu14, tend, 0);
      Arteries[ 14] -> printPxt (fpu15, tend, 0);
      Arteries[ 15] -> printPxt (fpu16, tend, 0);
      Arteries[ 16] -> printPxt (fpu17, tend, 0);
      Arteries[ 17] -> printPxt (fpu18, tend, 0);
      Arteries[ 18] -> printPxt (fpu19, tend, 0);
      Arteries[ 19] -> printPxt (fpu20, tend, 0);
      Arteries[ 20] -> printPxt (fpu21, tend, 0);
*/
    // The time within each print is increased.
    tstart = tend;
    tend   = tend + Deltat; // The current ending time is increased by Deltat.
  }
//  fprintf(stdout,"\n");

  // The following statements is used when timing the simulation.
  //fprintf(stdout,"nbrves = %d, Lax, ", nbrves);
  //clock_t c2 = clock(); // FIXME clock() may wrap after about 72 min.
  //int tsec = (int) ((double) (c2-c1)/CLOCKS_PER_SEC);
  //fprintf(stdout,"cpu-time %d:%02d\n", tsec / 60, tsec % 60);
  //fprintf(stdout,"\n");
  

  // In order to termate the program correctly the vessel network and hence
  // all the vessels and their workspace are deleted.
  for (int i=0; i<nbrves; i++) delete Arteries[i];

  // Matrices and arrays are deleted
  for (int i=0; i<18; i++) delete[] fjac[i];
  
  fclose (fpu1);
/*  fclose (fpu2);
  fclose (fpu3);
  fclose (fpu4);
  fclose (fpu5);
  fclose (fpu6);
  fclose (fpu7);
  fclose (fpu8);
  fclose (fpu9);
  fclose (fpu10);
  fclose (fpu11);
  fclose (fpu12);
  fclose (fpu13);
  fclose (fpu14);
  fclose (fpu15);
  fclose (fpu16);
  fclose (fpu17);
  fclose (fpu18);
  fclose (fpu19);
	  fclose (fpu20);
	  fclose (fpu21);
*/

//    fprintf(stdout, "Closing Files: \n");
//    if (fclose (fpu1)  != EOF) fprintf(stdout,"1pu OK, ");
//    else error("main.C","Close 1pu NOT OK");
//    if (fclose (fpu2)  != EOF) fprintf(stdout,"2pu OK, ");
//    else error("main.C","Close 2pu NOT OK");
//    if (fclose (fpu3)  != EOF) fprintf(stdout,"3pu OK, ");
//    else error("main.C","Close 3pu NOT OK");
//    fclose (fpu1);
//    fclose (fpu2);
//    fclose (fpu3);
//    fprintf(stdout, "\n");
    
  return 0;
}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GP Adaptive RMHMC with Bayesian Optimization for
%%%%% step size and no of steps in the RMHMC algorithm%%%%%%%%%%%%
%%% papers: Rasmussen's Gaussian Processes to Speed up Hybrid Monte Carlo for Expensive Bayesian Integrals
% Adaptive Hamiltonian and Riemann Manifold Monte Carlo Samplers by Wang and Freitas
% and Riemann Manifold HMC by Calderhead
clear; close all;

% Add necessary paths (e.g. to GPstuff or CommonFunctions) ...

% make the PDE code
!make clean
!make

% Load exploratory phase results
load('PaperResults_GPHMC_Exploratory.mat')

% Load the real data

trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');

% Set some parameters
id = 400; % id for data files
nd = 4; % no of parameters
extra_p = [id, nd];
n = size(truePressure,1);
do_nuts = 0; corrErr = 0; gp_ind = NaN; GP_hyperHyper = NaN(6,1);

% Bounds for original parameters
l = [7e04, -0.5, -0.5, -2.5];
u = [5e05, 1.92, 1.0, 1.5];

% Parameter scaling for emulation
sc = [10^6, 10, 10, 10];

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded parameters theta
% Be(1,1) = Uniform
alp = [1,1,1,1];
bet = [1,1,1,1];

do_DA = 1; % do delayed acceptance

%% Obtain an initial GP model for the objective function: normalised ESJD
if 1
    initime = cputime;
    hd = 2; % no of hyperparameters for RMHMC (epsilon, L)
    % Set lower and upper bounds for epsilon and L to be used in
    % Bayesian optimization
    l_HMC = [10^(-2), 1];
    u_HMC = [8*10^(-2), 40];
    sc_E = u_HMC; % scaling for (eps, L) to be used in GP
    
    X = sobolset(hd, 'Skip',1.4e4,'Leap',0.45e15); % draw 21 points
    np = size(X, 1);
    
    % Use first 20 points from Sobol sequence to build initial GP model
    epsilon_init = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(1:np,1);
    L_init = round(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(1:np,2)); % L integer
    
    % Set number of RMHMC samples to generate for every (eps, L) pair
    nSamples = 11; % draw nSamples-1 for every (eps,L) starting from previous run sample
    % (that'll be the 1st out of nSamples)    
    
    % Sampling phase in Rasmussen's paper
    phase_ind = 2;
    
    % Pre-allocate memory for chains
    p_sample_init = NaN((nSamples-1)*(np-1)+1, nd); % parameter samples from initial stage
    nESJD_init = NaN(np,1); % normalised ESJD from initial stage (only the successful runs (nESJD>0))
    
    ss_sample_init = NaN((nSamples-1)*(np-1)+1, 1); % sum-of-square (SS) samples from the sampling phase
    s2_sample_init = NaN((nSamples-1)*(np-1)+1, 1); % noise variance samples from the sampling phase
 
    % Set Newton steps for implicit fixed iterations
    NumOfNewtonSteps = 4;
    
    % Initialise position vector
    j = 1;
    p0 = x_regr_refitted(j,:) .* sc; % original scale
    p_sample_init(1,:) = log((p0-l)./(u-p0)); % unbounded
    
    rss_optim = 64; % comes from an initial optimisation of SS function
    S20 = rss_optim/(n-nd); % prior for sigma2
    N0 = 1; % prior accuracy for S20
    
    noPDE_counter_preproc = 0; % count no of PDE evaluations in the pre-processing phase
    
    [NLL, pass] = Run_simulator(p0./sc, extra_p, truePressure, sc, gp_ind, corrErr);
    
    noPDE_counter_preproc = noPDE_counter_preproc + 1;
    
    ss_sample_init(1) = NLL;
    s2_sample_init(1) = ss_sample_init(1)/(n-nd);
    
    if pass == 0
        disp('Choose different starting values for the parameters')
    end
    
    
    em_ind = 0; % use simulator for beginning of trajectory
    grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
    [LogPosterior_sim, ~, ~, ~, ~, ss_sample_init(1)] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample_init(1,:), ...
        s2_sample_init(1), truePressure, ...
        alp, bet, GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
    
    noPDE_counter_preproc = noPDE_counter_preproc + 1;
    
    em_ind = 1;
    grad1_SimInd = NaN; grad23_EmInd = [1 1];
    [LogPosterior_em, GradLogPost_em, GradGradLogPost_em, GradGradGradLogPost_em] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample_init(1,:), ...
        s2_sample_init(1), truePressure, ...
        alp, bet, GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
    
    acc = 0;
    next = 1;
    for j = 1:np-1 % iterate through different (eps, L) pairs
        % to obtain nSamples for each pair
        for i=2:nSamples
            
            next = next + 1;
            [p_sample_init(next,:),LogPosterior_sim,LogPosterior_em,...
                GradLogPost_em,GradGradLogPost_em,GradGradGradLogPost_em,...
                ss_sample_init(next), noPDE_counter_iter] = ...
                RMHMC_pulm(p_sample_init(next-1,:), s2_sample_init(next-1), ...
                epsilon_init(j), ceil(rand*L_init(j)), ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                gp_class, x_class, y_class, nd, phase_ind, truePressure, ...
                alp, bet, extra_p, l, u, sc, LogPosterior_sim, ...
                LogPosterior_em, GradLogPost_em, GradGradLogPost_em, ...
                GradGradGradLogPost_em, ss_sample_init(next-1), mean_y, std_y, ...
                do_nuts, corrErr, gp_ind, GP_hyperHyper, invLref, do_DA, NumOfNewtonSteps);
            
            noPDE_counter_preproc = noPDE_counter_preproc + noPDE_counter_iter;
            
            
            if all(p_sample_init(next,:) ~= p_sample_init(next-1,:)) % i.e. we've just accepted the new point
                %disp('accept')
                acc = acc + 1;
            end
            
            s2_sample_init(next) = 1/gamrnd((N0+n)/2, 2/(N0*S20+ss_sample_init(next)));
            
            
        end
        
        xj = p_sample_init(next-nSamples+1:next,:);
        nESJD_init(j) = ESJDfct(xj)/sqrt(L_init(j));
        %nESJD_init(j)
    end
    
    % Construct data set: ((eps, L), nESJD_init) on which we run initial GP model
    % nESJD_init must have np length
    x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np-1,2) size
    y_E = nESJD_init(1:np-1);
    
    mean_y_E = mean(y_E);
    std_y_E = std(y_E);
    
    y_E = (y_E-mean_y_E)./std_y_E; % mean 0 and std 1 of of y_E
    
    gp_E = GPmodel_BlackBox(x_E, y_E, l_HMC./sc_E, u_HMC./sc_E);
    
    %Make predictions using gp_E
    [E, Var] = gp_pred(gp_E, x_E, y_E, x_E);
    figure(1); clf(1); plot(y_E, E, '.', 'markersize', 20);
    hold on; plot(y_E,y_E,'-r')
    xlabel('Train data'); ylabel('Predictions')
    
    fintime = cputime;
    time_preprocessing_AdaptiveRMHMC=fintime-initime;
    
    save('PaperResults_AdaptiveRMHMC_initialDesign.mat')
    
end

%% Sampling phase
load('PaperResults_AdaptiveRMHMC_initialDesign.mat')

k = 100; alpha = 4; delta = 0.1; % parameters needed for BO
% Set number of RMHMC samples to generate for every (eps, L) pair
n_burnin = 500; n_samples = 5000;
n_adapt_hmc_burnin = floor(n_burnin/(nSamples-1)); % no of samples to draw in the burnin phase
n_adapt_hmc = ceil(n_samples/(nSamples-1)); % no of samples to draw in the sampling phase
% total no of samples drawn will be 1 + (nSamples-1)*n_adapt_hmc + (nSamples-1)*n_adapt_hmc_burnin

nrun = 10; % run 10 chains in parallel

epsilon_adapt = cell(nrun,1); % stores the optimum step size from every BO iteration
L_adapt = cell(nrun,1); % stores the optimum no of leapfrog steps from every BO iteration

for j = 1:nrun
    epsilon_adapt{j}(1) = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(np,1);
    L_adapt{j}(1) = round(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(np,2)); % L integer
end

phase_ind = 2; % sampling phase

p_sample = cell(nrun,1); % param samples
s2_sample = cell(nrun,1); % sigma2 samples
ss_sample = cell(nrun,1); % sum-of-square samples

nESJD = cell(nrun,1);

% Initialise position vector with last param values from the initial design
for j = 1:nrun
    p0 = x_regr_refitted(end-10*j,:) .* sc; % original scale
    p0 = log((p0-l)./(u-p0)); % unbounded
    p_sample{j}(1,:) = p0;
end

rss_optim = 64;
S20 = rss_optim/(n-nd); % prior for sigma2
N0 = 1; % prior accuracy for S20

noPDE_counter_proc = zeros(nrun,1); % count no of PDE evaluations in the processing (sampling) phase

delete(gcp('nocreate'))
parpool('local', nrun)

parfor j = 1:nrun
    
    extra_p = [j+40, nd];
    
    p0 = (u.*exp(p_sample{j}(1,:))+l)./(1+exp(p_sample{j}(1,:)));% original scale
    p0 = p0./sc;
    [NLL, pass] = Run_simulator(p0, extra_p, truePressure, sc, gp_ind, corrErr);
    ss_sample{j}(1) = NLL;
    if pass == 1
        s2_sample{j}(1) = ss_sample{j}(1)/(n-nd);
    else
        disp('Choose different starting values for the parameters')
    end
end

acc = zeros(nrun,1); % acceptance rates for every chain

% Store cpu times for every run and average the at the end
initime = NaN(nrun,1);
fintime = NaN(nrun,1);

% Run 10 chains in parallel from different initialisations and different
% random seed generators
parfor run = 1:nrun
    
    noPDE_counter_run = 0;
    
    extra_p = [run+40, nd];
    nESJD_augm = nESJD_init(1:np-1); % this is unscaled
    x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np,2) size
    x_E_augm = x_E; % already scaled
    
    em_ind = 0; % use simulator for beginning of trajectory
    grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
    [LogPosterior_sim, ~, ~, ~, ~, NLL_begin] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample{run}(1,:), s2_sample{run}(1), ...
        truePressure, alp, bet, GP_hyperHyper, extra_p, l, u, sc, ...
        em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
        
    em_ind = 1;
    grad1_SimInd = NaN; grad23_EmInd = [1 1];
    [LogPosterior_em, GradLogPost_em, GradGradLogPost_em, GradGradGradLogPost_em] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample{run}(1,:), s2_sample{run}(1), ...
        truePressure, alp, bet, GP_hyperHyper, extra_p, l, u, sc, ...
        em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
    
%     s = alpha/max(nESJD_augm); % make sure max(nESJD_augm)~=0
%     
%     if ~isfinite(s)
%         error('Obtain more values of nESJD_augm, as its max is 0')
%     end
    
    dup_noBo = 0; % no of duplicates as a consequence of skipping the BO step
    next = 1;
    weight = linspace(0.01, 1, n_adapt_hmc_burnin)'; % we'll apply decreasing weighting for duplicates in burnin phase
    del_ind = 0; % tracks total no of elements removed bc they're duplicates
    
    for j = 1:n_adapt_hmc+n_adapt_hmc_burnin
        % Run RMHMC nSample times for [epsilon_adapt(j), L_adapt(j)]
        for i = 2:nSamples
            next = next + 1;
            
            if next == n_burnin+1
                initime(run) = cputime;
            end
            
            [p_sample{run}(next,:),LogPosterior_sim,LogPosterior_em,GradLogPost_em,...
                GradGradLogPost_em, GradGradGradLogPost_em, ...
                ss_sample{run}(next), no_counter_iter] = ...
                RMHMC_pulm(p_sample{run}(next-1,:), s2_sample{run}(next-1), ...
                epsilon_adapt{run}(j), ceil(rand*L_adapt{run}(j)), ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                gp_class, x_class, y_class, ...
                nd, phase_ind, truePressure, alp, bet, extra_p, l, u, sc, ...
                LogPosterior_sim, LogPosterior_em, GradLogPost_em, GradGradLogPost_em, ...
                GradGradGradLogPost_em, ss_sample{run}(next-1), ...
                mean_y, std_y, do_nuts, corrErr, ...
                gp_ind, GP_hyperHyper, invLref, do_DA, NumOfNewtonSteps);
            
            if next > n_burnin
                noPDE_counter_run = noPDE_counter_run + no_counter_iter;
            end
            
            if all(p_sample{run}(next,:) ~= p_sample{run}(next-1,:)) % i.e. we've just accepted the new point
                %disp('accept')
                acc(run) = acc(run) + 1;
            end
            
            % Sample noise variance from an Inverse-Gamma
            s2_sample{run}(next) = 1/gamrnd((N0+n)/2, 2/(N0*S20+ss_sample{run}(next)));
            
           if mod(next,1000) == 0
                parsave_AdaptiveAlg(sprintf('ARMHMC_run %d.mat', run),...
                    p_sample{run},ss_sample{run},s2_sample{run})
           end
           
        end % nSamples
        
        %If we have gathered np data points in the sampling phase for the GP,
        %discard the points from the burnin phase (np points)
        %not to affect the inference
        if (j == 2*np)
            nESJD_augm(1:j) = []; x_E_augm(1:j,:) = [];
        end
        
        % Obtain the objective function
        xj = p_sample{run}(next-nSamples+1:next,:);
        nESJD{run}(j) = ESJDfct(xj)/sqrt(L_adapt{run}(j));
        
        % Augment data set with ([eps(j), L(j)], nESJD(j)) 
        
        nESJD_augm(end+1) = nESJD{run}(j);
        x_E_augm(end+1,:) = [epsilon_adapt{run}(j), L_adapt{run}(j)]./sc_E;
        
        % Draw o ~ Unif([0 1])
        o = rand;
        
        % Update parameter for adaptation p_adapt
        pj = (max(j-k+1,1))^(-0.5);
        
        % Conduct the Bayesian Optimization step
        if o > pj % no update
            dup_noBo = dup_noBo + 1;
            epsilon_adapt{run}(j+1) = epsilon_adapt{run}(j);
            L_adapt{run}(j+1) = L_adapt{run}(j);

        else % update: minimise negative nESJD_augm using BO
            % Check if we have duplicates and average them before fitting gp
            % weighted average in burnin phase and equal average in sampling phase
            if j <= n_adapt_hmc_burnin 
                %disp('burnin phase')
                
                if dup_noBo ~= 0 % we have previous duplicates, so
                    % we average nESJD for previous (eps, L) that are duplicates
                    %disp('We have duplicates BO')
                    nESJD_weightedavg = ( weight(end)*nESJD_augm(end) + ...
                        nESJD_augm((end-dup_noBo):(end-1))'* ...
                        weight((end-dup_noBo):(end-1)) ) /...
                        ( sum(weight((end-dup_noBo):end)) );
                    nESJD_augm((end-dup_noBo):end) = [];
                    del_ind = del_ind + dup_noBo;
                    nESJD_augm(end+1) = nESJD_weightedavg;
                    
                    hyp = x_E_augm(end,:);
                    x_E_augm((end-dup_noBo):end,:) = [];
                    x_E_augm(end+1,:) = hyp;
                                        
                    % else, no previous duplicates, so we use all [x_E_augm,
                    % nESJD_augm] to fit the GP
                end
                
            else % sampling phase
                %disp('sampling phase')
                
                if dup_noBo ~= 0 % we have previous duplicates, so
                    % we average nESJD for previous (eps, L) that are duplicates
                    
                    %disp('We have duplicates BO')
                    nESJDavg = mean(nESJD_augm((end-dup_noBo):end));
                    nESJD_augm((end-dup_noBo):end) = [];
                    del_ind = del_ind + dup_noBo;
                    nESJD_augm(end+1) = nESJDavg;
                    
                    hyp = x_E_augm(end,:);
                    x_E_augm((end-dup_noBo):end,:) = [];
                    x_E_augm(end+1,:) = hyp;
                    
                    % else, no previous duplicates, so we use all [x_E_augm,
                    % nESJD_augm] to fit the GP
                end
            end % j <= n_adapt_hmc_burnin
            
            dup_noBo = 0;
            
%             % Update s, the scale invariance parameter
%             if max(nESJD_augm) == nESJD{run}(j)
%                 s = alpha/nESJD{run}(j);
%             end

            s = 1; % since we scale the rewards to mean 0, var 1 anyway
            
            % Re-train GP
            mean_y_E = mean(nESJD_augm);
            std_y_E = std(nESJD_augm);
            x_E = x_E_augm; y_E = (nESJD_augm - mean_y_E)./std_y_E;
            
            
            % Do BO
            betaj = 2*log((pi^2*(j+1)^(hd/2+2))/(3*delta));
            fh_ucb = @(x_new) UpperConfBound(x_new, gp_E, x_E, y_E, ...
                mean_y_E, std_y_E, s, pj, betaj);
            % Set the options for optimizer of the acquisition function
            optimf = @fmincon;
             
            optdefault=struct('LargeScale','off','Display', 'off', ...
                'Algorithm','active-set','TolFun',1e-8,'TolX',1e-8, ...
                'GradObj','on','SpecifyObjectiveGradient',true);
            
            options = optimset(optdefault);
            
            nstarts = 12; % multiple restarts since acquisition fct usually multimodal
            x0_E = NaN(nstarts, hd);
            x_E_optims = NaN(nstarts, hd); f_E_optims = NaN(nstarts, 1);
            for s1 = 1:nstarts
                % initial epsilon and L for the optimization
                x0_E(s1,:) = l_HMC./sc_E+(u_HMC-l_HMC)./sc_E * rand;
                [x_E_optims(s1,:), f_E_optims(s1)] = ...
                    optimf(fh_ucb, x0_E(s1,:), [], [], [], [], ...
                    l_HMC./sc_E, u_HMC./sc_E, [], options);
                
            end
            
            I_min = find(f_E_optims==min(f_E_optims));
            x_E_optim = x_E_optims(I_min(1),:);
            f_E_optim = f_E_optims(I_min(1));
            
            % Store new optimum
            epsilon_adapt{run}(j+1) = x_E_optim(1)*sc_E(1);
            L_adapt{run}(j+1) = round(x_E_optim(2)*sc_E(2)); % L integer
            

        end % o>pj
        
    end %n_adapt_hmc
    
    noPDE_counter_proc(run) = noPDE_counter_proc(run) + noPDE_counter_run;
    
    fintime(run) = cputime;
    
end %parfor

time_AdaptiveRMHMC_BO = mean(fintime-initime);

save('PaperResults_AdaptiveRMHMC_BO.mat')
exit;